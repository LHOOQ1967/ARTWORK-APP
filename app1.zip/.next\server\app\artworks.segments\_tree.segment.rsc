:HL["/_next/static/chunks/104syq7s~5geg.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"(protected)","param":null,"prefetchHints":0,"slots":{"children":{"name":"artworks","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}},"staleTime":300,"buildId":"Gm2e3Ji1-Jl9NhKfY3Gk1"}
