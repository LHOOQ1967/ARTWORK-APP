module.exports=[18742,(a,b,c)=>{}];

//# sourceMappingURL=0zjb_server_app_%28protected%29_artworks_%28detail%29_%5Bid%5D_page_actions_0gc_b04.js.map