module.exports=[23270,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_contacts_new_page_actions_0yzkt...js.map