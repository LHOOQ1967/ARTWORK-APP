module.exports=[60672,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_artworks_%5Bid%5D_documents_reorder_route_actions_0~w8fg6.js.map