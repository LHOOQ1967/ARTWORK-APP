var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/artworks/[id]/proposals/route.js")
R.c("server/chunks/[root-of-the-server]__0pbmb1f._.js")
R.c("server/chunks/node_modules_103okmr._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/_next-internal_server_app_api_artworks_[id]_proposals_route_actions_0bdo9e7.js")
R.m(80227)
module.exports=R.m(80227).exports
