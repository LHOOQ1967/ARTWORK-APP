var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/artworks/print/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0k0.hin._.js")
R.c("server/chunks/node_modules_103okmr._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_artworks_print_[id]_route_actions_0gwsk6v.js")
R.m(80581)
module.exports=R.m(80581).exports
