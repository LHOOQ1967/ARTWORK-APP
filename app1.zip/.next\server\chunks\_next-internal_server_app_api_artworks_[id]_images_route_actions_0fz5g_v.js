module.exports=[30675,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_artworks_%5Bid%5D_images_route_actions_0fz5g_v.js.map