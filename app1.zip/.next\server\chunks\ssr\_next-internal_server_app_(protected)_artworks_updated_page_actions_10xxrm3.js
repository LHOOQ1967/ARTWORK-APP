module.exports=[253,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_artworks_updated_page_actions_10xxrm3.js.map