var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/artworks/[id]/proposals/[proposalId]/route.js")
R.c("server/chunks/[root-of-the-server]__0umhgp5._.js")
R.c("server/chunks/node_modules_103okmr._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/0zjb_server_app_api_artworks_[id]_proposals_[proposalId]_route_actions_0h5n.rv.js")
R.m(49600)
module.exports=R.m(49600).exports
