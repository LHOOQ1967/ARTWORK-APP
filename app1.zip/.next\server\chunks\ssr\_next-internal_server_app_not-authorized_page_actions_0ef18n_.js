module.exports=[1664,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_not-authorized_page_actions_0ef18n_.js.map