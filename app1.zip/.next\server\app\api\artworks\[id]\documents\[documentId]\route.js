var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/artworks/[id]/documents/[documentId]/route.js")
R.c("server/chunks/[root-of-the-server]__02lk2uo._.js")
R.c("server/chunks/node_modules_103okmr._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/0zjb_server_app_api_artworks_[id]_documents_[documentId]_route_actions_0s1_a1i.js")
R.m(63469)
module.exports=R.m(63469).exports
