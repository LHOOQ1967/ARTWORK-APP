module.exports=[18167,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_artworks_%5Bid%5D_documents_%5BdocumentId%5D_route_actions_0s1_a1i.js.map