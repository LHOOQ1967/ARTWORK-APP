1:"$Sreact.fragment"
2:I[5512,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0~2i2jb2m8ct9.js","/_next/static/chunks/0p16ac57_6.yk.js","/_next/static/chunks/0u1ze4237f8cq.js","/_next/static/chunks/0qro9ejstmwzt.js"],"default"]
3:I[97367,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/0qro9ejstmwzt.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"8gfH3QooMyg1NqQx-iww7"}
5:null
