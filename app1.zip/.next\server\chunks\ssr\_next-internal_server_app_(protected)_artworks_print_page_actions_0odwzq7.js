module.exports=[47804,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_artworks_print_page_actions_0odwzq7.js.map