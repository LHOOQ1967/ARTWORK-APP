module.exports=[93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},6900,e=>{"use strict";var t=e.i(87022),r=e.i(93458);async function a(){let e=await (0,r.cookies)();return(0,t.createServerClient)("https://cdbtgjhbgswpdehqwjnn.supabase.co","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNkYnRnamhiZ3N3cGRlaHF3am5uIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU4MjY4MTMsImV4cCI6MjA5MTQwMjgxM30.H4vAoeB4zSz2cUTThwDvHtxPy1OOWbM0DV4juryWuhM",{cookies:{get:t=>e.get(t)?.value,set(t,r,a){e.set({name:t,value:r,...a})},remove(t,r){e.set({name:t,value:"",...r})}}})}e.s(["supabaseServer",0,a])},80581,e=>{"use strict";var t=e.i(47909),r=e.i(74017),a=e.i(96250),n=e.i(59756),s=e.i(61916),i=e.i(74677),o=e.i(69741),l=e.i(16795),d=e.i(87718),u=e.i(95169),c=e.i(47587),p=e.i(66012),h=e.i(70101),m=e.i(26937),x=e.i(10372),v=e.i(93695);e.i(52474);var w=e.i(5232),R=e.i(89171),_=e.i(6900);async function f(e,{params:t}){let{id:r}=await t;if(!r)return R.NextResponse.json({error:"Missing artwork id"},{status:400});let a=await (0,_.supabaseServer)(),{data:n,error:s}=await a.from("artworks").select(`
      *,
      artist:artists (
        id,
        first_name,
        last_name,
        year_of_birth,
        year_of_death
      ),
      documents:documents (
        id,
        document_type,
        label,
        url,
        artwork_id
      ),
      proposedBy:contacts!artworks_proposed_by_id_fkey (
        id,
        first_name,
        last_name,
        company_name
      ),
      auctionHouse:contacts!artworks_auction_contact_id_fkey (
        id,
        first_name,
        last_name,
        company_name
      ),
      buyer:contacts!artworks_buyer_contact_id_fkey (
        id,
        first_name,
        last_name,
        company_name
      ),
      location:contacts!artworks_location_contact_fkey (
        id,
        first_name,
        last_name,
        company_name
      ),
      certificateLocation:contacts!artworks_certificate_location_contact_id_fkey (
        id,
        first_name,
        last_name,
        company_name
      )
    `).eq("id",r).single();return s||!n?R.NextResponse.json({error:"Artwork not found"},{status:404}):R.NextResponse.json(n)}e.s(["GET",0,f],80385);var y=e.i(80385);let g=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/artworks/print/[id]/route",pathname:"/api/artworks/print/[id]",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/artworks/print/[id]/route.ts",nextConfigOutput:"",userland:y,...{}}),{workAsyncStorage:k,workUnitAsyncStorage:E,serverHooks:b}=g;async function C(e,t,a){a.requestMeta&&(0,n.setRequestMeta)(e,a.requestMeta),g.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let R="/api/artworks/print/[id]/route";R=R.replace(/\/index$/,"")||"/";let _=await g.prepare(e,t,{srcPage:R,multiZoneDraftMode:!1});if(!_)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:f,params:y,nextConfig:k,parsedUrl:E,isDraftMode:b,prerenderManifest:C,routerServerContext:A,isOnDemandRevalidate:N,revalidateOnlyGenerated:I,resolvedPathname:T,clientReferenceManifest:S,serverActionsManifest:j}=_,q=(0,o.normalizeAppPath)(R),M=!!(C.dynamicRoutes[q]||C.routes[T]),O=async()=>((null==A?void 0:A.render404)?await A.render404(e,t,E,!1):t.end("This page could not be found"),null);if(M&&!b){let e=!!C.routes[T],t=C.dynamicRoutes[q];if(t&&!1===t.fallback&&!e){if(k.adapterPath)return await O();throw new v.NoFallbackError}}let P=null;!M||g.isDev||b||(P="/index"===(P=T)?"/":P);let H=!0===g.isDev||!M,U=M&&!H;j&&S&&(0,i.setManifestsSingleton)({page:R,clientReferenceManifest:S,serverActionsManifest:j});let D=e.method||"GET",F=(0,s.getTracer)(),B=F.getActiveScopeSpan(),$=!!(null==A?void 0:A.isWrappedByNextServer),K=!!(0,n.getRequestMeta)(e,"minimalMode"),z=(0,n.getRequestMeta)(e,"incrementalCache")||await g.getIncrementalCache(e,k,C,K);null==z||z.resetRequestCache(),globalThis.__incrementalCache=z;let J={params:y,previewProps:C.preview,renderOpts:{experimental:{authInterrupts:!!k.experimental.authInterrupts},cacheComponents:!!k.cacheComponents,supportsDynamicResponse:H,incrementalCache:z,cacheLifeProfiles:k.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a,n)=>g.onRequestError(e,t,a,n,A)},sharedContext:{buildId:f}},L=new l.NodeNextRequest(e),G=new l.NodeNextResponse(t),V=d.NextRequestAdapter.fromNodeNextRequest(L,(0,d.signalFromNodeResponse)(t));try{let n,i=async e=>g.handle(V,J).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=F.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==u.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${D} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t),n&&n!==e&&(n.setAttribute("http.route",a),n.updateName(t))}else e.updateName(`${D} ${R}`)}),o=async n=>{var s,o;let l=async({previousCacheEntry:r})=>{try{if(!K&&N&&I&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await i(n);e.fetchMetrics=J.renderOpts.fetchMetrics;let o=J.renderOpts.pendingWaitUntil;o&&a.waitUntil&&(a.waitUntil(o),o=void 0);let l=J.renderOpts.collectedTags;if(!M)return await (0,p.sendResponse)(L,G,s,J.renderOpts.pendingWaitUntil),null;{let e=await s.blob(),t=(0,h.toNodeOutgoingHttpHeaders)(s.headers);l&&(t[x.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==J.renderOpts.collectedRevalidate&&!(J.renderOpts.collectedRevalidate>=x.INFINITE_CACHE)&&J.renderOpts.collectedRevalidate,a=void 0===J.renderOpts.collectedExpire||J.renderOpts.collectedExpire>=x.INFINITE_CACHE?void 0:J.renderOpts.collectedExpire;return{value:{kind:w.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await g.onRequestError(e,t,{routerKind:"App Router",routePath:R,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:N})},!1,A),t}},d=await g.handleResponse({req:e,nextConfig:k,cacheKey:P,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:C,isRoutePPREnabled:!1,isOnDemandRevalidate:N,revalidateOnlyGenerated:I,responseGenerator:l,waitUntil:a.waitUntil,isMinimalMode:K});if(!M)return null;if((null==d||null==(s=d.value)?void 0:s.kind)!==w.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(o=d.value)?void 0:o.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});K||t.setHeader("x-nextjs-cache",N?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),b&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let u=(0,h.fromNodeOutgoingHttpHeaders)(d.value.headers);return K&&M||u.delete(x.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||t.getHeader("Cache-Control")||u.get("Cache-Control")||u.set("Cache-Control",(0,m.getCacheControlHeader)(d.cacheControl)),await (0,p.sendResponse)(L,G,new Response(d.value.body,{headers:u,status:d.value.status||200})),null};$&&B?await o(B):(n=F.getActiveScopeSpan(),await F.withPropagatedContext(e.headers,()=>F.trace(u.BaseServerSpan.handleRequest,{spanName:`${D} ${R}`,kind:s.SpanKind.SERVER,attributes:{"http.method":D,"http.target":e.url}},o),void 0,!$))}catch(t){if(t instanceof v.NoFallbackError||await g.onRequestError(e,t,{routerKind:"App Router",routePath:q,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:U,isOnDemandRevalidate:N})},!1,A),M)throw t;return await (0,p.sendResponse)(L,G,new Response(null,{status:500})),null}}e.s(["handler",0,C,"patchFetch",0,function(){return(0,a.patchFetch)({workAsyncStorage:k,workUnitAsyncStorage:E})},"routeModule",0,g,"serverHooks",0,b,"workAsyncStorage",0,k,"workUnitAsyncStorage",0,E],80581)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0k0.hin._.js.map