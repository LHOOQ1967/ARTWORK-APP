globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/tPeDFIvO85TQ5QoKiyC7M/_buildManifest.js",
    "static/tPeDFIvO85TQ5QoKiyC7M/_ssgManifest.js",
    "static/tPeDFIvO85TQ5QoKiyC7M/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ze4gu236oq96.js",
    "static/chunks/0k3omv9igz_rv.js",
    "static/chunks/0mstyq17cbf8-.js",
    "static/chunks/14.rr0ukvgjw1.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/turbopack-0sr2yguag4v1i.js"
  ]
};
