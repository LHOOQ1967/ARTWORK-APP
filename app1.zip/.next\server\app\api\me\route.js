var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/me/route.js")
R.c("server/chunks/[root-of-the-server]__0gm-ig-._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/_next-internal_server_app_api_me_route_actions_0awbrgh.js")
R.m(21455)
module.exports=R.m(21455).exports
