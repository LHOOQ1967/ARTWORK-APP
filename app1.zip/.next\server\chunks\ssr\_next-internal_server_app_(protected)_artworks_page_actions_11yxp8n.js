module.exports=[36803,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_artworks_page_actions_11yxp8n.js.map