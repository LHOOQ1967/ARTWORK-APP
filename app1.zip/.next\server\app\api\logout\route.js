var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/logout/route.js")
R.c("server/chunks/[root-of-the-server]__09o7dvt._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_logout_route_actions_09pke_j.js")
R.m(55778)
module.exports=R.m(55778).exports
