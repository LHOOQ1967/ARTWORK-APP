module.exports=[30151,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_artists_new_page_actions_0-l_ugp.js.map