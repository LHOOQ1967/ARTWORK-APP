var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/artworks/[id]/images/route.js")
R.c("server/chunks/[root-of-the-server]__0b~m6ag._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_artworks_[id]_images_route_actions_0fz5g_v.js")
R.m(68033)
module.exports=R.m(68033).exports
