module.exports=[1431,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(50431);a.s(["default",0,function({params:a}){let{id:e}=(0,c.use)(a);return(0,b.jsx)(d.default,{artworkId:e,isEditMode:!0})}])}];

//# sourceMappingURL=app_%28protected%29_artworks_%5Bid%5D_edit_page_tsx_0dvseg5._.js.map