module.exports=[20214,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_artworks_print_%5Bid%5D_route_actions_0gwsk6v.js.map