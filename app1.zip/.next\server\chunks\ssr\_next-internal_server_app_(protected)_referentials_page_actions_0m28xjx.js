module.exports=[47660,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_referentials_page_actions_0m28xjx.js.map