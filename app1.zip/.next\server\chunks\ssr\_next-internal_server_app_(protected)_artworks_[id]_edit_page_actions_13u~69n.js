module.exports=[25120,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_artworks_%5Bid%5D_edit_page_actions_13u~69n.js.map