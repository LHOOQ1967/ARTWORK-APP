var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/artworks/checks/missing-proposed-at/route.js")
R.c("server/chunks/[root-of-the-server]__0a04rek._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/0zjb_server_app_api_artworks_checks_missing-proposed-at_route_actions_126wzfg.js")
R.m(46412)
module.exports=R.m(46412).exports
