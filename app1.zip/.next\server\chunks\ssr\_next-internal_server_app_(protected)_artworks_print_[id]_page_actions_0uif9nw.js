module.exports=[82542,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_artworks_print_%5Bid%5D_page_actions_0uif9nw.js.map