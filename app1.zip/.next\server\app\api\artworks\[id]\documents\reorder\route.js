var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/artworks/[id]/documents/reorder/route.js")
R.c("server/chunks/[root-of-the-server]__0x5cixh._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/0zjb_server_app_api_artworks_[id]_documents_reorder_route_actions_0~w8fg6.js")
R.m(38746)
module.exports=R.m(38746).exports
