module.exports=[40322,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_artworks_%5Bid%5D_documents_route_actions_01~9urb.js.map