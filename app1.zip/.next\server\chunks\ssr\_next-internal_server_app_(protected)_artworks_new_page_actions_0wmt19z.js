module.exports=[10773,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_artworks_new_page_actions_0wmt19z.js.map