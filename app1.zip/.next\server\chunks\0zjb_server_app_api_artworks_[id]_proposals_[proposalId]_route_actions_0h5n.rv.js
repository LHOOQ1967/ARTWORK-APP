module.exports=[1029,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_artworks_%5Bid%5D_proposals_%5BproposalId%5D_route_actions_0h5n.rv.js.map