1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"ClientSegmentRoot"]
3:I[62971,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0~2i2jb2m8ct9.js","/_next/static/chunks/0p16ac57_6.yk.js","/_next/static/chunks/0u1ze4237f8cq.js","/_next/static/chunks/0rncsqt0iqxdz.js"],"default"]
4:I[39756,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
5:I[37457,["/_next/static/chunks/01xlw8hd842-c.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/0rncsqt0iqxdz.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"eUIw3TtPDcOzvwwgPOloo"}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
