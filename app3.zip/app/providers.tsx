
'use client'

export function AppSupabaseProvider({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
